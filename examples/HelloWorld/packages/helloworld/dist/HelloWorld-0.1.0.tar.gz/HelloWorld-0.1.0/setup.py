from distutils.core import setup
setup(
    name='HelloWorld',
    version='0.1.0',
    packages=['helloworld'],
    scripts=['bin/helloworld.py'],
    description='Simpel Hello World Package'
)